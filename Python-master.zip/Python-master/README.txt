文件說明

本資料集為Python課程之學習筆記，以資料型態及函式之應用實例為主。
以[Python100例]為演練題庫，依據主題及關聯編排十個章節，文件中均已載明試題、參考解析及備忘註解供參。
參考網頁 https://www.runoob.com/python/python-100-examples.html


茲列章節綱要:

Example 01　基本操作: 數值
Example 02　基本操作: 字串
Example 03　基本操作: 列表(1)
Example 04　基本操作: 列表(2)
Example 05　基本操作: 其他
Example 06　應用問題: 數字
Example 07　應用問題: 質、因數
Example 08　應用問題: 數列遞迴
Example 09　情境實例(1)
Example 10　情境實例(2)
